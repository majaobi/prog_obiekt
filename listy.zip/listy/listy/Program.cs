﻿namespace listy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Person> persons = new List<Person>();
            Person p1 = new Person("Maja", "Obi");
            Person p2 = new Person("Filip", "Piatek");
            Person p3 = new Person("Kuba", "Buba");

            persons.Add(p1);
            persons.Add(p1);
            persons.Add(p2);

            Console.WriteLine(persons.Count); //3

            Console.WriteLine(persons[1].lastName); //Obi

            foreach( Person p in persons)
            {
                Console.WriteLine(p.firstName+" "+p.lastName);
            }
            Console.WriteLine("\n\n");
            persons.Insert(0, p2);

            foreach (Person p in persons)
            {
                Console.WriteLine(p.firstName + " " + p.lastName);
            }
            persons.Add(new Person("Dawid", "Bartniczak"));
            Console.WriteLine(persons.Count+ "\n\n"); 
            
            Console.WriteLine(persons.Contains(p1)); //true
            Console.WriteLine(persons.Contains(p3)); //false

            Console.WriteLine(persons.IndexOf(p1)); //1
            Console.WriteLine(persons.IndexOf(p3)); //-1
            
            persons.Remove(p1);

            Console.WriteLine(persons.IndexOf(p1)); 
            Console.WriteLine(persons.Count);
            Console.WriteLine("\n\n");
            persons.RemoveAt(0);
            foreach (Person p in persons)
            {
                Console.WriteLine(p.firstName + " " + p.lastName);
            }
            Console.WriteLine("\n\n");

            string[] names = { "Janusz", "Anna" };
            List<string> stringsList= new List<string>();
            stringsList.AddRange(names);

            foreach (string i in stringsList)
            {
                Console.WriteLine(i + " ");
            }
            Console.WriteLine("\n\n");

            string[] namesList = stringsList.ToArray();
            foreach (string i in namesList)
            {
                Console.WriteLine(i + " ");
            }
            Console.WriteLine("\n\n");

            string[] cities = { "Poznan", "Mosina" };
            stringsList.AddRange(cities);

            foreach (string i in stringsList)
            {
                Console.WriteLine(i + " ");
            }
            Console.WriteLine("\n\n");

            stringsList.InsertRange(1, cities);

            foreach (string i in stringsList)
            {
                Console.WriteLine(i + " ");
            }
            Console.WriteLine("\n\n");
            stringsList.Insert(1, "new");


            foreach (string i in stringsList)
            {
                Console.WriteLine(i + " ");
            }
            Console.WriteLine("\n\n");




        }
    }
}